package com.mindtree.shoppingcart.contoller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.shoppingcart.dto.ProductListDto;
import com.mindtree.shoppingcart.dto.ProductsDtoFilter;
import com.mindtree.shoppingcart.exception.ShoppingCartException;
import com.mindtree.shoppingcart.service.ProductsService;
import com.mindtree.shoppingcart.service.UserServiceInterface;

@RestController
public class HomeController {

@Autowired
UserServiceInterface userService;
@Autowired
ProductsService productsService;


@GetMapping("/getproductsbycategory/{category}")
public List<ProductsDtoFilter> getProductsByCategory(@PathVariable String category)throws ShoppingCartException{
	 List<ProductsDtoFilter> products= productsService.getProductsByCategory(category);
	 return products;
}

@GetMapping("/getproductsbyname/{productName}") 
public ProductsDtoFilter getProductsByName(@PathVariable String productName) throws ShoppingCartException{
	 ProductsDtoFilter products=productsService.getProductsByName(productName);
	 return products;
}

@GetMapping("/getproductsbyid/{productId}")
public ProductsDtoFilter getProductsById(@PathVariable int productId) throws ShoppingCartException{
	ProductsDtoFilter products=productsService.getProductsById(productId);
	return products;
	
}
@PostMapping("/addcart/{userId}/{cartId}")
public ResponseEntity<Map<String,Object>> addUser(@PathVariable int userId, @PathVariable int cartId) throws ShoppingCartException{
	
	Map<String, Object> response= new HashMap<String,Object>();
	response.put("Headers:", "add carts");
	response.put("Error", false);
		response.put("body", userService.addUser(userId,cartId));
	response.put("Http Status:", HttpStatus.OK);
	return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
}
@PostMapping("/addproduct/{userId}/{productId}")
public ResponseEntity<Map<String,Object>> addProduct(@PathVariable int userId, @PathVariable int productId) throws ShoppingCartException{
	
	Map<String, Object> response= new HashMap<String,Object>();
	response.put("Headers:", "add product");
	response.put("Error", false);
		response.put("body", productsService.addProduct(userId,productId));
	response.put("Http Status:", HttpStatus.OK);
	return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
}
@GetMapping("/deleteproduct/{userId}/{productId}")
public ResponseEntity<Map<String,Object>> deleteProduct(@PathVariable int userId, @PathVariable int productId) throws ShoppingCartException{
	
	Map<String, Object> response= new HashMap<String,Object>();
	response.put("Headers:", "delete product");
	response.put("Error", false);
		response.put("body", productsService.deleteProduct(userId,productId));
	response.put("Http Status:", HttpStatus.OK);
	return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
}

@GetMapping("/updateproduct/{userId}/{productId}/{quantity}")
public ResponseEntity<Map<String,Object>> subtractProduct(@PathVariable int userId, @PathVariable int productId,@PathVariable int quantity) throws ShoppingCartException{
	Map<String, Object> response= new HashMap<String,Object>();
	response.put("Headers:", "subtract product");
	response.put("Error", false);
		response.put("body", productsService.subtractProduct(userId,productId,quantity));
	response.put("Http Status:", HttpStatus.OK);
	return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
}
@GetMapping("/emptycart/{userId}")
public ResponseEntity<Map<String,Object>> emptyCart(@PathVariable int userId) throws ShoppingCartException{
	Map<String, Object> response= new HashMap<String,Object>();
	response.put("Headers:", "empty cart");
	response.put("Error", false);
		response.put("body", productsService.emptyCart(userId));
	response.put("Http Status:", HttpStatus.OK);
	return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
}
@GetMapping("/amountpaid/{userId}")
public ResponseEntity<Map<String,Object>> amountPaid(@PathVariable int userId) throws ShoppingCartException{
	Map<String, Object> response= new HashMap<String,Object>();
	response.put("Headers:", "amount paid");
	response.put("Error", false);
		response.put("body", productsService.amountPaid(userId));
	response.put("Http Status:", HttpStatus.OK);
	return new ResponseEntity<Map<String,Object>>(response, HttpStatus.OK);
}
@GetMapping("/getallproducts/{userId}")
public ProductListDto getAllProductsInCart(@PathVariable int userId) throws ShoppingCartException{
	ProductListDto products= productsService.getAllProductsInCart(userId);
	 return products;
}
}