package com.mindtree.shoppingcart.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mindtree.shoppingcart.entity.Products;

@Repository
public interface ProductsRepository extends JpaRepository<Products, Integer> {

	
	@Query("Select p from Products p where products_category=:category")
	Optional<List<Products>> findAllProducts(String category);
	
	@Query("Select p from Products p where product_name=:productName")
	Optional<Products> findAllProductByName(String productName);
	
	@Query("Select p from Products p where product_id=:productId")
	Optional<Products> findProductById(int productId);
}
