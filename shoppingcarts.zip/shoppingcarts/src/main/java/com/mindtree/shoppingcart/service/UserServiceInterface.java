package com.mindtree.shoppingcart.service;

import com.mindtree.shoppingcart.exception.service.ShoppingCartServiceException;

/**
 * @author M1056017
 @param userId
 @param cartId
 @return "assigned"
 */
public interface UserServiceInterface {
public String addUser(int userId,int cartId) throws ShoppingCartServiceException;
}
