package com.mindtree.shoppingcart.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
@Data
public class ProductAmountDto {
private int id;
private int productQuantity;
@JsonIgnoreProperties("product")
private ProductsDto product;
@JsonIgnoreProperties("cart")
private CartDto cart;

}
