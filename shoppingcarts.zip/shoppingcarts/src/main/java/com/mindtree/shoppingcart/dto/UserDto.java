package com.mindtree.shoppingcart.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
@Data
public class UserDto {
private int userId;
private String userName;
@JsonIgnoreProperties("user")
private CartDto userCart;

}
