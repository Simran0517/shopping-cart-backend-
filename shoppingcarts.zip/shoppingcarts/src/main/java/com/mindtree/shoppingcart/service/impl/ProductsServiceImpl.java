package com.mindtree.shoppingcart.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.shoppingcart.dto.ProductsDtoFilter;
import com.mindtree.shoppingcart.entity.Cart;
import com.mindtree.shoppingcart.entity.ProductAmount;
import com.mindtree.shoppingcart.entity.Products;
import com.mindtree.shoppingcart.entity.User;
import com.mindtree.shoppingcart.exception.service.CartNotFoundException;
import com.mindtree.shoppingcart.exception.service.ProductNotFoundException;
import com.mindtree.shoppingcart.exception.service.ProductQuantityCantBeNegativeException;
import com.mindtree.shoppingcart.exception.service.ShoppingCartServiceException;
import com.mindtree.shoppingcart.exception.service.UserNotFoundException;
import com.mindtree.shoppingcart.repository.ApparalRepository;
import com.mindtree.shoppingcart.repository.BookRepository;
import com.mindtree.shoppingcart.repository.CartRepository;
import com.mindtree.shoppingcart.repository.ProductAmountRepository;
import com.mindtree.shoppingcart.repository.ProductsRepository;
import com.mindtree.shoppingcart.repository.UserRepository;
import com.mindtree.shoppingcart.dto.ProductListDto;
import com.mindtree.shoppingcart.dto.ProductsDto;
import com.mindtree.shoppingcart.service.ProductsService;
@Service
public class ProductsServiceImpl implements ProductsService{
@Autowired
CartRepository cartRepository;
@Autowired
UserRepository userRepository;
@Autowired
ProductsRepository productsRepository;
@Autowired
ProductAmountRepository productAmountRepository;
@Autowired
BookRepository bookRepository;
@Autowired
ApparalRepository apparalRepository;

ModelMapper modelMapper = new ModelMapper();

@Transactional
@Override
public List<ProductsDtoFilter> getProductsByCategory(String category) throws ShoppingCartServiceException
{
	Optional<List<Products>> productList= productsRepository.findAllProducts(category);
	productList.orElseThrow(()-> new ProductNotFoundException());
	List<Products> productNewList=new ArrayList<Products>();
	productNewList=productList.get();
	List<ProductsDtoFilter> productsList = productNewList.stream().map(p-> modelMapper.map(p, ProductsDtoFilter.class)).collect(Collectors.toList());
	return productsList;
}
@Transactional
@Override
public ProductsDtoFilter getProductsByName(String productName)throws ShoppingCartServiceException
{
	Optional<Products> product= productsRepository.findAllProductByName(productName);
	product.orElseThrow(()-> new ProductNotFoundException());
	Products products=new Products();
	products=product.get();
	
	ProductsDtoFilter productNew = modelMapper.map(products, ProductsDtoFilter.class);
	
	return productNew;
}

@Transactional
@Override
public ProductsDtoFilter getProductsById(int productId) throws ShoppingCartServiceException
{
	Optional<Products> product= productsRepository.findProductById(productId);
	product.orElseThrow(()-> new ProductNotFoundException());
	Products products=new Products();
	products=product.get();
	
	ProductsDtoFilter productNew = modelMapper.map(products, ProductsDtoFilter.class);
	
	return productNew;
}
@Transactional
@Override
public String addProduct(int userId, int productId) throws ShoppingCartServiceException {
	Optional<Products> product= productsRepository.findProductById(productId);
	product.orElseThrow(()-> new ProductNotFoundException());
	Products products=new Products();
	products=product.get();
	Optional<User> userOptional=userRepository.findById(userId);
	userOptional.orElseThrow(()-> new UserNotFoundException());
	User user =new User();
	user=userOptional.get();
	List<ProductAmount> productAmountList=productAmountRepository.findAll();
	if(null!=user && null!= user.getUserCart()) {
		Cart cart=user.getUserCart();
		List<ProductAmount> productAmountWithCartId=productAmountList.stream().filter(p->p.getCart().getCartId()==cart.getCartId()).collect(Collectors.toList());
		if(productAmountWithCartId.size()==0) {
			ProductAmount productAmount=new ProductAmount();
			productAmount.setProduct(products);
			productAmount.setCart(cart);
			productAmount.setProductQuantity(1);
			productAmountRepository.save(productAmount);
		}
		else {
			List<ProductAmount> productAmountWithProductId = productAmountList.stream().filter(p->p.getProduct().getProductId()==productId && p.getCart().getCartId()==cart.getCartId()).collect(Collectors.toList());
			if(productAmountWithProductId.size()==0) {
				ProductAmount productAmount2=new ProductAmount();
				productAmount2.setProduct(products);
				productAmount2.setCart(cart);
				productAmount2.setProductQuantity(1);
				productAmountRepository.save(productAmount2);
			}
			else {
				for(ProductAmount p: productAmountList) {
					if(p.getProduct().getProductId()==productId && p.getCart().getCartId()==cart.getCartId()) {
						p.setProductQuantity(p.getProductQuantity()+1);
						productAmountRepository.save(p);
					}
				}
			}
		}
	}
	
	return "updated";
}
@Transactional
@Override
public String deleteProduct(int userId, int productId) throws ShoppingCartServiceException {
	Optional<User> userOptional=userRepository.findById(userId);
	userOptional.orElseThrow(()-> new UserNotFoundException());
	User user=userOptional.get();
	Cart cart=user.getUserCart();
	List<ProductAmount> productAmountList=productAmountRepository.findAll();
	List<ProductAmount> productAmountWithCartId=productAmountList.stream().filter(p->p.getCart().getCartId()==cart.getCartId()).collect(Collectors.toList());
	for(ProductAmount p: productAmountWithCartId) {
		if(p.getProduct().getProductId()==productId)
			productAmountRepository.deleteById(p.getId());
	else {
		throw new ProductNotFoundException();
	}
	}
	return "product deleted";
}
@Transactional
@Override
public String subtractProduct(int userId, int productId, int quantity) throws ShoppingCartServiceException {
	Optional<User> userOptional=userRepository.findById(userId);
	userOptional.orElseThrow(()-> new UserNotFoundException());
	User user=userOptional.get();
	Cart cart=user.getUserCart();
	List<ProductAmount> productAmountList=productAmountRepository.findAll();
	List<ProductAmount> productAmountWithCartId=productAmountList.stream().filter(p->p.getCart().getCartId()==cart.getCartId()).collect(Collectors.toList());
	for(ProductAmount p: productAmountWithCartId) {
		if(p.getProduct().getProductId()==productId) {
			if(quantity>0)
			{
				p.setProductQuantity(quantity);
				productAmountRepository.save(p);
			}
			else if(quantity==0){
				productAmountRepository.deleteById(p.getId());
			}else {
				throw new ProductQuantityCantBeNegativeException();
			}
		}
		else {
			throw new ProductNotFoundException();
		}
}
return "quantity updated";
}
@Transactional
@Override
public String emptyCart(int userId) throws ShoppingCartServiceException {
	Optional<User> userOptional=userRepository.findById(userId);
	userOptional.orElseThrow(()-> new UserNotFoundException());
	User user=userOptional.get();
	Cart cart=user.getUserCart();
	List<ProductAmount> productAmountList=productAmountRepository.findAll();
	List<ProductAmount> productAmountWithCartId=productAmountList.stream().filter(p->p.getCart().getCartId()==cart.getCartId()).collect(Collectors.toList());
	for(ProductAmount p: productAmountWithCartId) {
		productAmountRepository.deleteById(p.getId());
	}
	return "emptied the cart";
}
@Transactional
@Override
public String amountPaid(int userId) throws ShoppingCartServiceException {
	List<ProductAmount> productAmountList=productAmountRepository.findAll();
	float amountToBePaid=0;
	for(ProductAmount p:productAmountList) {
		if(p.getCart().getUser().getUserId()==userId) {
			amountToBePaid=amountToBePaid+p.getProduct().getProductPrice()*p.getProductQuantity();
			
		}
		else {
			throw new UserNotFoundException();
		}
	}
	return "The amount to be paid by the user is " + amountToBePaid;
}
@Transactional
@Override
public ProductListDto getAllProductsInCart(int userId) throws ShoppingCartServiceException {
	Optional<User> user = userRepository.findById(userId);
	ProductListDto productList=new ProductListDto();
	List<ProductsDto> productnewList=new ArrayList<ProductsDto>();
	user.orElseThrow(()-> new UserNotFoundException());
	int cartId=user.get().getUserCart().getCartId();
	List<ProductAmount> productAmountList=productAmountRepository.findAll();
	float amountToBePaid=0;
	for(ProductAmount p: productAmountList)
	{
		if(p.getCart().getCartId()==cartId) {
			amountToBePaid=amountToBePaid+p.getProduct().getProductPrice()*p.getProductQuantity();
			ProductsDto productDto=new ProductsDto();
			productDto.setProductName(p.getProduct().getProductName());
			productDto.setProductPrice(p.getProduct().getProductPrice());
			productDto.setProductQuantity(p.getProductQuantity());
			productnewList.add(productDto);
			productList.setProductsList(productnewList);
			productList.setAmounttopay(amountToBePaid);
		}
	}
	return productList;
	
}





}
