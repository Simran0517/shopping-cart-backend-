package com.mindtree.shoppingcart.dto;

import java.util.List;

import lombok.Data;
@Data
public class ProductListDto {
private List<ProductsDto> productsList;
private float amounttopay;


}
