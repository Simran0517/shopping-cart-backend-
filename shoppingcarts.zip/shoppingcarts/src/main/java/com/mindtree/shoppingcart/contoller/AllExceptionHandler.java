package com.mindtree.shoppingcart.contoller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


import com.mindtree.shoppingcart.exception.service.ProductNotFoundException;
import com.mindtree.shoppingcart.exception.service.ProductQuantityCantBeNegativeException;
import com.mindtree.shoppingcart.exception.service.UserNotFoundException;

@ControllerAdvice
public class AllExceptionHandler {
			@ExceptionHandler(value=ProductNotFoundException.class)
			public ResponseEntity<Object> exception(ProductNotFoundException exception){
				return new ResponseEntity<>("Product Not Found With The Given Search Value",HttpStatus.NOT_FOUND);
				
				
			}
			@ExceptionHandler(value=UserNotFoundException.class)
			public ResponseEntity<Object> exception(UserNotFoundException exception){
				return new ResponseEntity<>("User Not Found With The Searched Id",HttpStatus.NOT_FOUND);
				
				
			}
			@ExceptionHandler(value=ProductQuantityCantBeNegativeException.class)
			public ResponseEntity<Object> exception(ProductQuantityCantBeNegativeException exception){
				return new ResponseEntity<>("Product Quantity Cant Be Negative",HttpStatus.NOT_FOUND);
				
				
			}
		
}
