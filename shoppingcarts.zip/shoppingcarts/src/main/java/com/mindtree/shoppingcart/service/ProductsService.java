package com.mindtree.shoppingcart.service;

import java.util.List;

import com.mindtree.shoppingcart.dto.ProductListDto;
import com.mindtree.shoppingcart.dto.ProductsDtoFilter;
import com.mindtree.shoppingcart.exception.service.ShoppingCartServiceException;

public interface ProductsService {
	
	
	/**
	 * @author M1056017
	 @param category
	 @return productsList
	 */
	public List<ProductsDtoFilter> getProductsByCategory(String category) throws ShoppingCartServiceException;
	/**
	 @param productName
	 @return product
	 */
	public ProductsDtoFilter getProductsByName(String productName) throws ShoppingCartServiceException;
	/**
	 @param productId
	 @return product
	 */
	public ProductsDtoFilter getProductsById(int productId) throws ShoppingCartServiceException;
	/**
	 @param userId
	 @param productId
	 @return "updated"
	 */
	public String addProduct(int userId, int productId) throws ShoppingCartServiceException;
	/**
	 @param userId
	 @param productId
	 @return "product deleted"
	 */
	public String deleteProduct(int userId, int productId) throws ShoppingCartServiceException;
	/**
	 @param userId
	 @param productId
	 @param quantity
	 @return "quantity updated"
	 */
	public String subtractProduct(int userId, int productId, int quantity) throws ShoppingCartServiceException;
	/**
	 @param userId
	 @return "emptied the cart"
	 */
	public String emptyCart(int userId) throws ShoppingCartServiceException;
	/**
	 @param userId
	 @return "amount to be paid"
	 */
	public String amountPaid(int userId) throws ShoppingCartServiceException;
	/**
	 @param userId
	 @return productList
	 */
	public ProductListDto getAllProductsInCart(int userId) throws ShoppingCartServiceException;

}
