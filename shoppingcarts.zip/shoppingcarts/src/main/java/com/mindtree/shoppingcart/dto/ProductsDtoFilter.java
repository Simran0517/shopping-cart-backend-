package com.mindtree.shoppingcart.dto;

public class ProductsDtoFilter {
private String productName;
private float productPrice;
private String genre;
private String author;
private String publications;
private String type;
private String brand;
private String design;
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public float getProductPrice() {
	return productPrice;
}
public void setProductPrice(float productPrice) {
	this.productPrice = productPrice;
}
public String getGenre() {
	return genre;
}
public void setGenre(String genre) {
	this.genre = genre;
}
public String getAuthor() {
	return author;
}
public void setAuthor(String author) {
	this.author = author;
}
public String getPublications() {
	return publications;
}
public void setPublications(String publications) {
	this.publications = publications;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getBrand() {
	return brand;
}
public void setBrand(String brand) {
	this.brand = brand;
}
public String getDesign() {
	return design;
}
public void setDesign(String design) {
	this.design = design;
}
@Override
public String toString() {
	return "ProductsDtoFilter [productName=" + productName + ", productPrice=" + productPrice + ", genre=" + genre
			+ ", author=" + author + ", publications=" + publications + ", type=" + type + ", brand=" + brand
			+ ", design=" + design + "]";
}
public ProductsDtoFilter(String productName, float productPrice, String genre, String author, String publications,
		String type, String brand, String design) {
	super();
	this.productName = productName;
	this.productPrice = productPrice;
	this.genre = genre;
	this.author = author;
	this.publications = publications;
	this.type = type;
	this.brand = brand;
	this.design = design;
}
public ProductsDtoFilter() {
	super();
	// TODO Auto-generated constructor stub
}

}
