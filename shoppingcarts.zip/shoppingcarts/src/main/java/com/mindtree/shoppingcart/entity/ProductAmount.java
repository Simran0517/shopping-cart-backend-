package com.mindtree.shoppingcart.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class ProductAmount {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int id;
private int productQuantity;
@ManyToOne(fetch=FetchType.LAZY, cascade = CascadeType.PERSIST)
@JoinColumn(name="productId")
private Products product;
@ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.PERSIST)
@JoinColumn(name="cartId")
private Cart cart;


}
