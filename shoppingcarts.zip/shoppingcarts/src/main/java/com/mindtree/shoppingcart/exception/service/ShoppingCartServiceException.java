package com.mindtree.shoppingcart.exception.service;

import com.mindtree.shoppingcart.exception.ShoppingCartException;

public class ShoppingCartServiceException extends ShoppingCartException {

	public ShoppingCartServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ShoppingCartServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ShoppingCartServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ShoppingCartServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ShoppingCartServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
