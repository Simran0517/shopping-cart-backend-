package com.mindtree.shoppingcart.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
@Data
public class CartDto {
private int cartId;
@JsonIgnoreProperties("user")
private UserDto user;
@JsonIgnoreProperties("productAmountOfCart")
private List<ProductAmountDto> productAmountOfCart;

}
