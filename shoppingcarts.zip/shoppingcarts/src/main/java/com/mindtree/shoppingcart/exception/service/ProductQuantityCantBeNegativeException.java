package com.mindtree.shoppingcart.exception.service;

public class ProductQuantityCantBeNegativeException extends ShoppingCartServiceException{

	public ProductQuantityCantBeNegativeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductQuantityCantBeNegativeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ProductQuantityCantBeNegativeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ProductQuantityCantBeNegativeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ProductQuantityCantBeNegativeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
