package com.mindtree.shoppingcart.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToMany;
import javax.persistence.FetchType;

import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="Products_Category",discriminatorType = DiscriminatorType.STRING)
public class Products implements Comparable<Products> {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private int productId;
private String productName;
private float productPrice;
@OneToMany(fetch=FetchType.LAZY,cascade=CascadeType.PERSIST, mappedBy = "product")
@JsonBackReference
private List<ProductAmount> productAmountOfProduct;

@Override
public int compareTo(Products o) {
	return this.getProductId() - o.getProductId();
	
}

}
