package com.mindtree.shoppingcart.dto;

import lombok.Data;

@Data
public class ProductsDto {
private String productName;
private float productPrice;
private int productQuantity;

}
