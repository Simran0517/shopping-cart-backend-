package com.mindtree.shoppingcart.service.impl;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.shoppingcart.entity.Cart;
import com.mindtree.shoppingcart.entity.User;
import com.mindtree.shoppingcart.exception.service.CartNotFoundException;
import com.mindtree.shoppingcart.exception.service.ShoppingCartServiceException;
import com.mindtree.shoppingcart.exception.service.UserNotFoundException;
import com.mindtree.shoppingcart.repository.ApparalRepository;
import com.mindtree.shoppingcart.repository.BookRepository;
import com.mindtree.shoppingcart.repository.CartRepository;
import com.mindtree.shoppingcart.repository.ProductAmountRepository;
import com.mindtree.shoppingcart.repository.ProductsRepository;
import com.mindtree.shoppingcart.repository.UserRepository;
import com.mindtree.shoppingcart.service.UserServiceInterface;

@Service
public class UserServiceImpl implements UserServiceInterface {
	@Autowired
	CartRepository cartRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	ProductsRepository productsRepository;
	@Autowired
	ProductAmountRepository productAmountRepository;
	@Autowired
	BookRepository bookRepository;
	@Autowired
	ApparalRepository apparalRepository;

	ModelMapper modelMapper = new ModelMapper();

	@Override
	public String addUser(int userId, int cartId) throws ShoppingCartServiceException {
		
		Optional<User> userOptional=userRepository.findById(userId);
		userOptional.orElseThrow(()-> new UserNotFoundException());
		Optional<Cart> cartOptional=cartRepository.findById(cartId);
		cartOptional.orElseThrow(()-> new CartNotFoundException());
		User users=userOptional.get();
		Cart carts= cartOptional.get();
		users.setUserCart(carts);
		userRepository.save(users);
		return "assigned";
	}


}
